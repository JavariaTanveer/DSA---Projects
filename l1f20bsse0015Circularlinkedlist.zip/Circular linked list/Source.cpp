#include"My_clist.h"
#include<iostream>
using namespace std;
int main()
{
	My_clist * obj = new My_clist();
	cout << "Start inserting on head \n";
	obj->add_node_head(21);
	obj->add_node_head(22);
	obj->add_node_head(23);
	obj->display();
	cout << "Start removing from the head \n";
	obj->remove_from_head();
	obj->display();
	cout << "Start Inserting on the tail : \n";
	obj->add_node_tail(20);
	obj->add_node_tail(19);
	obj->add_node_tail(18);
	obj->display();
	cout << "Start removing from the tail : \n";
	obj->remove_from_tail();
	obj->display();

	system("pause");
}