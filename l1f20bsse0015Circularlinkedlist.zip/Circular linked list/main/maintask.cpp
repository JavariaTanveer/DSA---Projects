#include<iostream>
using namespace std;
struct node
{
	int data;
	node * next;
	node * prev;
};
class LinkedList
{
    private:
    node* head;
    node*  tail;
public :
	LinkedList()
	{
	head = nullptr;
	tail = nullptr;
	}
	void addatend(int data)
	{
		node* temp = new node;
		temp->data = data;
		temp->next = nullptr;
		temp->prev = nullptr;
		if (head == nullptr)
		{
			head = temp;
			tail = temp;
		}
		else
		{
			tail->next = temp;
			temp->prev =tail;
		    tail = temp;

		}
	}
	void addathead(int data)
	{
		node* temp = new node;
		temp->data = data;
		temp->next = nullptr;
		temp->prev = nullptr;
		if (head == nullptr)
		{
			
            head = temp;
			tail = temp;
		}
		else
		{
			temp->next =head;
			head->prev = temp;
			head = temp;
		}
	}
	int Search(int value)
	{
		node* temp = new node;
		temp= head;
		int pos = 0;
		while (temp->data != value && temp->next != nullptr) {
			pos++;
			temp = temp->next;
		}
		if (temp->data != value) {
			return -1;
		}
		return (pos + 1);
	}
	int Count()
	{
		node* temp = new node;
		temp =head;
		int count = 0;
		while (temp->next != nullptr) {
			count++;
			temp = temp->next;
		}
		return count + 1;
	}
	int Get_Total()
	{
		node* temp = new node;
		temp = head;
		int sum = 0;
		while (temp->next != nullptr) {
			sum += temp->data;
			temp = temp->next;
		}
		sum += temp->data;
		return sum;
	}
	void Reverse()
	{
		node* temp = new node;
		temp = nullptr;
		node* current = new node;
		current=head;

		while (current != nullptr)
		{
			temp = current->prev;
			current->prev = current->next;
			current->next = temp;
			current = current->prev;
		}
		if (temp != nullptr) {
			head = temp->prev;
		}
	}
    
	void processing()
	{
		int count = 0;
		node* temp = head;
		int modData = 0;
		while (1)
		{
			temp->data--;
			if (temp->data== 0)
			{
				deleteAnode(temp->data);
				temp = temp->next;
			}
			count++;
			
			cout << "count# " << count << "   :";
			display();
			cout << endl;
			if (head==NULL)
			{
				break;
			}
			temp=temp->next;
		}
	}
    void deleteAnode(int value)
	{
		if (head == NULL)
		{
			cout << "list is empty" << endl;
		}
		else
		{
			node* temp = head;
			while (temp->next!= head)
			{
					if (value == head->data)
					{
						node * temp = head;
		                head = head->next;
    		                temp->next = nullptr;
		                tail->next = head;
                        delete[] temp;
					}
					else if (temp->data == tail->data)
					{
						node * temp = head;
		                node * temp1 = head->next;
		                while (temp1->next!= head)
		                {
			            temp1 = temp1->next;
		                }
		                temp1->next = nullptr;
		                tail = temp;
		                tail->next = head;
                        delete[] temp;  
					}
					else
					{
						temp->next->prev = temp->prev;
						temp->prev->next = temp->next;
						delete[] temp;
					}
				temp = temp->next;
			}
		}
	}

	void display()
	{
		node* temp =head;
		cout << temp->data << " ";
		while (temp->next != nullptr)
		{
			temp = temp->next;
			cout << temp->data << " ";
		}
	}
};
int main()
{
	LinkedList list;
	list.addathead(2);
	list.addathead(3);
	list.addathead(4);
	list.addathead(1);
	list.addatend(20);
    list.addatend(30);
    
	list.display();
	cout << endl;
	list.processing();
	//list.insertAtPosition(20, 155);
	//list.insertAtPosition(150, 199);
	
	return 0;
}